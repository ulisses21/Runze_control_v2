To build the documentation, invoke:

````bash
make html
````
